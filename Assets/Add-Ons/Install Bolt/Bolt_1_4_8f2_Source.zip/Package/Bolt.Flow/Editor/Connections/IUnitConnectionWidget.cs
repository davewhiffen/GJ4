﻿using Ludiq;
using UnityEngine;

namespace Bolt
{
	public interface IUnitConnectionWidget : IGraphElementWidget
	{
		Color color { get; }
	}
}